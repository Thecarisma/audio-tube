# audio-tube
A wordpress plugin to embed a youtube, vimeo and other videos as audio on your wordpress site
